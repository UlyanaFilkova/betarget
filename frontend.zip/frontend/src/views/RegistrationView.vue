<script setup>
import "@/assets/css/default.css";
import RegistrationComponent from "@/components/RegistrationComponent.vue";
</script>

<template>
  <RegistrationComponent />
</template>
