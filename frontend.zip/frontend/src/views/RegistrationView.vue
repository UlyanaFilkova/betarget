<script setup>
import "@/assets/css/default.css";
import RegistrationComponent from "@/components/Registration.vue";
</script>

<template>
  <RegistrationComponent />
</template>
