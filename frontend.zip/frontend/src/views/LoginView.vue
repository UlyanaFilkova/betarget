<script setup>
import "@/assets/css/default.css";
import LoginComponent from "@/components/Login.vue";
</script>

<template>
  <LoginComponent />
</template>
