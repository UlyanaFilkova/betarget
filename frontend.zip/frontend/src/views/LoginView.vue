<script setup>
import "@/assets/css/default.css";
import LoginComponent from "@/components/LoginComponent.vue";
</script>

<template>
  <LoginComponent />
</template>
