<script setup>
import ResumeDisplay from "@/components/crmComponents/ResumeDisplay.vue";
import ResumeInfo from "@/components/crmComponents/ResumeInfo.vue";
</script>

<template>
  <div class="resume">
    <ResumeDisplay />
    <ResumeInfo />
    <div class="resume__not-chosen">Выберите резюме</div>
  </div>
</template>
