<template>
  <section class="resume-list"></section>
</template>
