<script setup>
import "@/assets/css/default.css";
import "@/assets/css/crm.css";
</script>

<style scoped>
.body__margin-top {
  height: 20px;
}
</style>

<template>
  <header>
    <div class="body__margin-top"></div>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap"
      rel="stylesheet"
    />
  </header>
</template>
